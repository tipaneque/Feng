import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Validacao {

    static BufferedReader x = new BufferedReader(new InputStreamReader(System.in));


}
