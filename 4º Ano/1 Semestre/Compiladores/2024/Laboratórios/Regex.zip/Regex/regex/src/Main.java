import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

    static BufferedReader x = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws IOException {
        //String reEmail = "[a-zA-Z0-9]+[@](gmail|hotmail)[.][a-zA-Z]{3}";
        //String reFirstName = "[A-Z]{1}[a-z]*";
        //String re1to12 = "[1-9]|1[0-2]";
        String day = "(0?[1-9]|[12]\\d|3[0-1])";
        String month = "([1-9]|1[0-2])";
        String year = "(19\\d{2}|20[0-2][0-4])";

        String date = day + "[/-]" + month;

        System.out.print("Type an date (DD/MM/AAAA): ");
        String test = x.readLine();

        Pattern ptTest = Pattern.compile(date);
        Matcher mtTest = ptTest.matcher(test);

        boolean resultEmail = mtTest.matches();
        System.out.println("Is valid Date?: " + resultEmail);
    }
}
